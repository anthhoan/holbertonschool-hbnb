from app.services.facade import HBnBFacade

facade = HBnBFacade()